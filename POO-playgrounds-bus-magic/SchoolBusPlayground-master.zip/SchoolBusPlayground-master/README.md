# SchoolBusPlayground
This project was made for OpenClassrooms. It's a playground dedicated to learn OOP in Swift. It comes with the OOP Swift course on OpenClassrooms.
